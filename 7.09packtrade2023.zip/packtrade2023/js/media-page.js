$(document).ready(function(){
    Fancybox.bind('[data-fancybox="mp-img"]')
})