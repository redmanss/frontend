$(document).ready(function(){
    Fancybox.bind('[data-fancybox="bp-img"]')
})